//$('.mymodal').on('click', '.modal-image', function() {
//    
//    
//});

$(function() {
    $('.modal-image').on('click', function() {
        
        $('.imagepreview').attr('src', $(this).attr('src'));
        $("#caption").text($(this).attr('alt'));
        
        $("#size").text($('.modal-image').attr('imagewidth') +" x " + $('.modal-image').attr('imageheight')+" px" );
        $("#photographer").text("Photographer: "+$(this).attr('photographer'));
        
        
        $('#imagemodal').modal('show');
    });
    
    $('.close').on('click', function(){
        $('#imagemodal').modal('hide'); 
    });
});
